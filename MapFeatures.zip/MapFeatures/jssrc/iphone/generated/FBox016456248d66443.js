function initializeFBox016456248d66443() {
    FBox016456248d66443 = new kony.ui.FlexContainer({
        "clipBounds": true,
        "height": "40dp",
        "id": "FBox016456248d66443",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "width": "100%"
    }, {}, {});
    FBox016456248d66443.setDefaultUnit(kony.flex.DP);
    var Button0545f303a01814f = new kony.ui.Button({
        "focusSkin": "slButtonGlossRed",
        "height": "35dp",
        "id": "Button0545f303a01814f",
        "isVisible": true,
        "left": "56dp",
        "skin": "slButtonGlossBlue",
        "text": "Button",
        "top": "0dp",
        "width": "260dp"
    }, {
        "containerWeight": 100,
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "hExpand": true,
        "margin": [6, 6, 6, 6],
        "marginInPixel": false,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {
        "showProgressIndicator": true
    });
    FBox016456248d66443.add(
    Button0545f303a01814f);
}