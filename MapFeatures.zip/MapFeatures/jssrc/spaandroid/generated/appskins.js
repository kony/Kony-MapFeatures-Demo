function skinsInit() {
    CopyslLabel007c62a735b5041 = "CopyslLabel007c62a735b5041";
    CopyslLabel062211baa3cc94c = "CopyslLabel062211baa3cc94c";
    slButtonGlossBlue = "slButtonGlossBlue";
    slButtonGlossRed = "slButtonGlossRed";
    slFbox = "slFbox";
    slForm = "slForm";
    slLabel = "slLabel";
    slPopup = "slPopup";
    slRadioButtonGroup = "slRadioButtonGroup";
    slTextArea = "slTextArea";
    slTextBox = "slTextBox";
    slTitleBar = "slTitleBar";
};