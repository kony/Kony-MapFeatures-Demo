kony.globals["appid"] = "KonyMapsFeature";
kony.globals["locales"] = [];