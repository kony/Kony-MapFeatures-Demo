function AS_Form_2bf324b3329a4529a1dc9d7b99d537c0() {
    frmCustomPin.destroy();
}