function AS_VBox_0064306bc35f45ccabfa8f954a1ce8da() {
    kony.print("@@@@ in vboxInfo onClick");
}