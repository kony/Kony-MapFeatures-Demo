function AS_Form_70e50808698b4017a28dfb090f349b0d() {
    frmMyRouteSearch.destroy();
}