function AS_Form_120abfc2f4e040e783f96791f8857181() {
    frmMyRouteSearch.mapRouteSearch.onClick = onRouteMapClick;
}