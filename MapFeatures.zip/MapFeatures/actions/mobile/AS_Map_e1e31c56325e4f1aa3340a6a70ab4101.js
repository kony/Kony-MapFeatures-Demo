function AS_Map_e1e31c56325e4f1aa3340a6a70ab4101() {
    kony.print("@@@@ in onClick of map ");
    frmRouteSearch.mapRouteSearch.onClick = onRouteMapClick;
}