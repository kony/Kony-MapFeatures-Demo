function AS_Map_c078a8529ad94e8b9458aaeddb60e698() {
    kony.print("@@@@ in onClick of map ");
}