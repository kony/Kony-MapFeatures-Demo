function AS_Form_0e60498d36b84201b76265f4e949880a() {
    frmRouteSearch.mapRouteSearch.onClick = onRouteMapClick;
    frmRouteSearch.flxscrlContainer.top = "90%";
    frmRouteSearch.flxscrlContainer.forceLayout();
    frmRouteSearch.forceLayout();
}