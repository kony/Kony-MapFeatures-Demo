function AS_Button_f7875b3df6ee47efaf49782d89746778() {
    animateDirection();
}