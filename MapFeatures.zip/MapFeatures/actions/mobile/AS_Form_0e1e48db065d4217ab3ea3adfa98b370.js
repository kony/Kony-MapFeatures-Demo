function AS_Form_0e1e48db065d4217ab3ea3adfa98b370() {
    frmRouteSearch.destroy();
}