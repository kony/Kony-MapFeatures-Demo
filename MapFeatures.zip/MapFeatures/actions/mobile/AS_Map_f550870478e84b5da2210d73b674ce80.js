function AS_Map_f550870478e84b5da2210d73b674ce80() {
    kony.print("@@@@ in onClick of map ");
    frmRouteSearch.mapRouteSearch.onClick = onRouteMapClick;
}