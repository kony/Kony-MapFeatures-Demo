function AS_Form_0c4b8e2ad48549108ab632c7baf0253c() {
    setPinFromFilePathAirPort();
    frmMyRouteSearch.mapRouteSearch.screenLevelWidget = false;
    searchRoutes_Mine();
}