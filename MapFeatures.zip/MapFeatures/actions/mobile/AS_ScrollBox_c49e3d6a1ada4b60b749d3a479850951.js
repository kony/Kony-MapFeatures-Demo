function AS_ScrollBox_c49e3d6a1ada4b60b749d3a479850951() {
    kony.print("@@@@ onPull");
}