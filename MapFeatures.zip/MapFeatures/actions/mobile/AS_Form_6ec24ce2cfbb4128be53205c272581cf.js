function AS_Form_6ec24ce2cfbb4128be53205c272581cf() {
    frmDrawPolygon.destroy();
}