function AS_Form_c2f38d8a496a4fadb08d1575afbce103() {
    var testdata1 = {
        id: "circleId",
        centerLocation: {
            lat: "17.441839",
            lon: "78.380928"
        },
        radius: 1
    }
    var testdata2 = {
        id: "circleId2",
        centerLocation: {
            lat: "17.447326",
            lon: "78.371358"
        },
        radius: 1
    }
    frmDrawCircle.mapDrawCircle.addCircle(testdata1);
    frmDrawCircle.mapDrawCircle.addCircle(testdata2);
}