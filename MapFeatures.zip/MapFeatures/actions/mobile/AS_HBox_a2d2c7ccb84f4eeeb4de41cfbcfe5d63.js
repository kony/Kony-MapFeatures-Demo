function AS_HBox_a2d2c7ccb84f4eeeb4de41cfbcfe5d63() {
    kony.print("@@@@ in hboxInfo onClick");
}