function AS_Form_2efcf7ce931a49db89f4d06ba2cc69c5() {
    setPinFromFilePathAirPort();
    frmRouteSearch.flxscrlContainer.opacity = 0;
    frmRouteSearch.mapRouteSearch.screenLevelWidget = false;
    searchRoutes_Mine();
}