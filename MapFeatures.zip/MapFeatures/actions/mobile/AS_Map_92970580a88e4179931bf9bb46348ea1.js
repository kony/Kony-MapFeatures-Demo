function AS_Map_92970580a88e4179931bf9bb46348ea1() {
    kony.print("@@@@ in onClick of map ");
    frmRouteSearch.mapRouteSearch.onClick = onRouteMapClick;
}