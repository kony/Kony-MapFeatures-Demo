function AS_Button_5ed92daab19145e987c5720c3a0858da() {
    animateDirection();
}