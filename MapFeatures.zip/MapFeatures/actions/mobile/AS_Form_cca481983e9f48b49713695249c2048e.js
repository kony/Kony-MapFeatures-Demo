function AS_Form_cca481983e9f48b49713695249c2048e() {
    setPinFromFilePathAirPort();
    frmRouteSearch.flxscrlContainer.opacity = 0;
    frmRouteSearch.mapRouteSearch.screenLevelWidget = false;
    searchRoutes_Mine();
}