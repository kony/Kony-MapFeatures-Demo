function AS_Form_8f81f7d97afa4e4facd0a098a9328157() {
    frmRouteSearch.mapRouteSearch.onClick = onRouteMapClick;
    frmRouteSearch.flxscrlContainer.top = "90%";
    frmRouteSearch.flxscrlContainer.forceLayout();
    frmRouteSearch.forceLayout();
}