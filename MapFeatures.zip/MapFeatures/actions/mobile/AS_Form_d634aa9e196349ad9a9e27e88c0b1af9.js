function AS_Form_d634aa9e196349ad9a9e27e88c0b1af9() {
    frmRouteSearch.destroy();
}