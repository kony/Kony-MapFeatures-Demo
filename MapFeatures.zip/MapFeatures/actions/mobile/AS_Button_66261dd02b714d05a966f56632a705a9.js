function AS_Button_66261dd02b714d05a966f56632a705a9() {
    animateDirection();
}