function AS_Button_5bf0eb6005eb4180accdb87c89ee6322() {
    animateDirection();
}