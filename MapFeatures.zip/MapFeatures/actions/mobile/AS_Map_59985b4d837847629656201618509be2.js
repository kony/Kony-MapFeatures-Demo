function AS_Map_59985b4d837847629656201618509be2() {
    frmMapRoute.map1.onClick = onRouteMapClick;
}