#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_KonySyncV2_ApplicationSync_symbols(JSContext*);
@protocol ApplicationSyncInstanceExports<JSExport>
@end
@protocol ApplicationSyncClassExports<JSExport>
JSExportAs(dropOnFailure,
+(void) jsdrop: (JSValue *) onSuccess onFailure: (JSValue *) onFailure );
+(void) setToken: (NSString *) token ;
JSExportAs(setupSyncOnSuccessOnFailure,
+(void) jssetupSync: (NSDictionary *) objectServiceList onSuccess: (JSValue *) onSuccess onFailure: (JSValue *) onFailure );
@end
#pragma clang diagnostic pop