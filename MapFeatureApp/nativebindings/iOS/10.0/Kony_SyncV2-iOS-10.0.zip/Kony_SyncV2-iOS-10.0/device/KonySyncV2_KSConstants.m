#import <objc/runtime.h>
#import "allincludes.h"
#import "ClassExtension.h"
#import "PointerSupport.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wincompatible-pointer-types"
#pragma clang diagnostic ignored "-Wnullability-completeness"
static void addProtocols()
{
}
static void registerCFunctions(JSContext* context)
{
}
static void registerEnumConstants(JSContext* context)
{
	context[@"SyncLevelObject"] = @0;
	context[@"SyncLevelObjectService"] = @1;
	context[@"SyncLevelApplication"] = @2;

	context[@"DelegateTaskCommandNone"] = @0;
	context[@"DelegateTaskCommandDataUpload"] = @1;
	context[@"DelegateTaskCommandDataDownload"] = @2;

	context[@"KSSDKObjectRecordActionUpdate"] = @0;
	context[@"KSSDKObjectRecordActionCreate"] = @1;
	context[@"KSSDKObjectRecordActionPartialUpdate"] = @2;
	context[@"KSSDKObjectRecordActionDelete"] = @3;
	context[@"KSSDKObjectRecordActionCreateOrIgnore"] = @4;
	context[@"KSSDKObjectRecordActionAll"] = @5;
	context[@"KSSDKObjectRecordActionNone"] = @6;
	context[@"KSSDKObjectRecordActionUnknown"] = @0;

	context[@"KSSDKObjectActionUpdate"] = @0;
	context[@"KSSDKObjectActionCreate"] = @1;
	context[@"KSSDKObjectActionCreateOrIgnore"] = @2;
	context[@"KSSDKObjectActionRead"] = @3;
	context[@"KSSDKObjectActionPartialUpdate"] = @4;
	context[@"KSSDKObjectActionDelete"] = @5;
	context[@"KSSDKObjectActionNone"] = @0;

	context[@"KSSDKObjectModeOffline"] = @0;
	context[@"KSSDKObjectModeOnline"] = @1;

	context[@"SyncSessionStateNotStarted"] = @0;
	context[@"SyncSessionStateStarted"] = @1;
	context[@"SyncSessionStatePausing"] = @2;
	context[@"SyncSessionStatePaused"] = @3;
	context[@"SyncSessionStateResuming"] = @4;
	context[@"SyncSessionStateStopping"] = @5;
	context[@"SyncSessionStateEnded"] = @6;
	context[@"SyncSessionStateErrored"] = @7;

	context[@"SyncSessionPhaseUnknown"] = @0;
	context[@"SyncSessionPhaseSetupStarted"] = @1;
	context[@"SyncSessionPhaseSetupEnded"] = @2;
	context[@"SyncSessionPhaseUploadStarted"] = @3;
	context[@"SyncSessionPhaseUploadNetworkOperationStarted"] = @4;
	context[@"SyncSessionPhaseUploadNetworkOperationEnded"] = @5;
	context[@"SyncSessionPhaseUploadObjectProcessingStarted"] = @6;
	context[@"SyncSessionPhaseUploadObjectProcessingEnded"] = @7;
	context[@"SyncSessionPhaseUploadPersistOperationStarted"] = @8;
	context[@"SyncSessionPhaseUploadPersistOperationEnded"] = @9;
	context[@"SyncSessionPhaseUploadEnded"] = @10;
	context[@"SyncSessionPhaseDownloadStarted"] = @11;
	context[@"SyncSessionPhaseDownloadNetworkOperationStarted"] = @12;
	context[@"SyncSessionPhaseDownloadNetworkOperationEnded"] = @13;
	context[@"SyncSessionPhaseDownloadObjectProcessingStarted"] = @14;
	context[@"SyncSessionPhaseDownloadObjectProcessingEnded"] = @15;
	context[@"SyncSessionPhaseDownloadPersistOperationStarted"] = @16;
	context[@"SyncSessionPhaseDownloadPersistOperationEnded"] = @17;
	context[@"SyncSessionPhaseDownloadEnded"] = @18;

	context[@"Ascending"] = @0;
	context[@"Descending"] = @1;

	context[@"Select"] = @0;

}
static void registerGlobalConstants(JSContext* context)
{
	void* p; p = NULL;
}
void load_KonySyncV2_KSConstants_symbols(JSContext* context)
{
    addProtocols();
    registerEnumConstants(context);
    registerCFunctions(context);
    registerGlobalConstants(context);
}
#pragma clang diagnostic pop
